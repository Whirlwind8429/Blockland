if(!$filmbotbinds)
{
	$filmbotbinds = 1;
	$remapdivision[$remapcount] = "FilmBots";
	$remapname[$remapcount] = "Film Scene";
	$remapcmd[$remapcount] = "fb_filmscene";
	$remapcount++;
	$remapname[$remapcount] = "Film With All Scenes";
	$remapcmd[$remapcount] = "fb_filmall";
	$remapcount++;
	$remapname[$remapcount] = "Play All Scenes";
	$remapcmd[$remapcount] = "fb_playall";
	$remapcount++;
	$remapname[$remapcount] = "End Scene";
	$remapcmd[$remapcount] = "fb_endscene";
	$remapcount++;
	$remapname[$remapcount] = "Delete Last Scene";
	$remapcmd[$remapcount] = "fb_delete";
	$remapcount++;
}

function fb_filmscene(%x)
{
	
	if(%x)
		commandToServer('filmscene');
}

function fb_filmall(%x)
{
	if(%x)
		commandToServer('filmwithscene',"-");
}

function fb_playall(%x)
{
	if(%x)
		commandToServer('playscene',"-");
}

function fb_endscene(%x)
{
	if(%x){
		commandToServer('endscene');}
}

function fb_delete(%x)
{
	if(%x)
		commandToServer('deletescene',"last");
}



if(isFile("./version.txt"))
{
	%a=new FileObject();
	%a.openforread(expandFileName("./version.txt"));
	while(!%a.isEOF())
	{
		%b=%a.readline();
		if(getField(%b,0)$="version")
		{
			$FB::Version=getField(%b,1);
			break;
		}
	}
}
if($FB::Version$="")
	$FB::Version=1;

//Ping-Pong is from the compass mod. All credits go to the original creator for this.
//This is a safe and good way to check if the server has the mod and if the client has the clientside.

function clientcmdFB_ping(%x)
{
	commandtoserver('FB_pong',%x,$FB::Version);
	$FBServer = 1;
	activatepackage(filmbots_client);
}

function clientcmdFB_Film(%toggle)
{
	if(%toggle)
	{
		$FB::Filming=1;
	}
	else
	{
		$FB::Filming=0;
	}
}

package filmbots_client
{
	function disconnect(%a)
	{
		if($FBServer)
		{
			commandtoserver('endscene');
			$FBServer = 0;
			deactivatepackage(filmbots_client);
		}parent::disconnect(%a);
	}

	function yaw(%x)
	{
		parent::yaw(%x);
		if($FB::Filming)
			commandtoserver('FB_eyes');
	}
	function pitch(%x)
	{
		parent::pitch(%x);
		if($FB::Filming)
			commandtoserver('FB_eyes');
	}

	function moveforward(%x)
	{
		parent::moveforward(%x);
		if($FB::Filming)
			commandtoserver('FB_film',2,%x);
	}

	function movebackward(%x)
	{
		parent::movebackward(%x);
		if($FB::Filming)
			commandtoserver('FB_film',3,%x);
	}

	function moveleft(%x)
	{
		parent::moveleft(%x);
		if($FB::Filming)
			commandtoserver('FB_film',4,%x);
	}

	function moveright(%x)
	{
		parent::moveright(%x);
		if($FB::Filming)
			commandtoserver('FB_film',5,%x);
	}

	function jump(%x)
	{
		parent::jump(%x);
		if($FB::Filming)
			commandtoserver('FB_film',6,%x);
	}

	function crouch(%x)
	{
		parent::crouch(%x);
		if($FB::Filming)
			commandtoserver('FB_film',7,%x);
	}

	function jet(%x)
	{
		parent::jet(%x);
		if($FB::Filming)
			commandtoserver('FB_film',8,%x);
	}

	function mouseFire(%x)
	{
		parent::mouseFire(%x);
		if($FB::Filming)
			commandtoserver('FB_film',9,%x);
	}

	function Suicide(%x)
	{
		parent::Suicide(%x);
		if($FB::Filming)
		{
			commandtoserver('FB_film',10,%x);
			commandtoserver('endscene',"suicide");
		}
	}

	function useLight(%x)
	{
		parent::useLight(%x);
		if($FB::Filming)
			commandtoserver('FB_film',11,%x);
	}

	function emoteSit(%x)
	{
		parent::emoteSit(%x);
		if($FB::Filming)
			commandtoserver('FB_film',12,%x);
	}
	
	function walk(%x)
	{
		parent::walk(%x);
		if($FB::Filming)
			commandtoserver('FB_film', 14, %x);
	}
	
	function toggleFreeLook(%x)
	{
		parent::toggleFreeLook(%x);
		if($FB::Filming)
			commandtoserver('FB_film', 15, %x);
	}
	
	function scrollTools(%x)
	{
		parent::scrollTools(%x);
		if($FB::Filminga)
			commandtoserver('FB_tools');
	}
	
	function useTools(%x)
	{
		parent::useTools(%x);
		if($FB::Filming && %x)
			commandtoserver('FB_Tools');
	}

	function useSprayCan(%x)
	{
		parent::useSprayCan(%x);
		if($FB::Filming && %x)
			commandtoserver('FB_Tools');
	}
	
	function invUp(%x)
	{
		parent::invUp(%x);
		if($FB::Filming && %x)
			commandtoserver('FB_Tools');
	}

	function invDown(%x)
	{
		parent::invDown(%x);
		if($FB::Filming && %x)
			commandtoserver('FB_Tools');
	}

	function invLeft(%x)
	{
		parent::invLeft(%x);
		if($FB::Filming && %x)
			commandtoserver('FB_Tools');
	}

	function invRight(%x)
	{
		parent::invRight(%x);
		if($FB::Filming && %x)
			commandtoserver('FB_Tools');
	}
	
	function emoteLove(%x)
	{
		parent::emoteLove(%x);
		if($FB::Filming)
			commandtoserver('FB_film',16, %x);
	}

	function emoteHate(%x)
	{
		parent::emoteHate(%x);
		if($FB::Filming)
			commandtoserver('FB_film',17, %x);
	}

	function emoteConfusion(%x)
	{
		parent::emoteConfusion(%x);
		if($FB::Filming)
			commandtoserver('FB_film',18, %x);
	}

	function emoteAlarm(%x)
	{
		parent::emoteAlarm(%x);
		if($FB::Filming)
			commandtoserver('FB_film',19, %x);
	}
	
};
