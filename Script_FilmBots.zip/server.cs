if(isFile("./version.txt"))
{
	%a=new FileObject();
	%a.openforread(expandFileName("./version.txt"));
	while(!%a.isEOF())
	{
		%b=%a.readline();
		if(getField(%b,0)$="version")
		{
			$FB::Version=getField(%b,1);
			break;
		}
	}
}
if($FB::Version$="")
	$FB::Version=1;
$FB::filmbotdamage=1;
package filmBots_server
{
	//Ping-Pong is from the compass mod. All credits go to the original creator for this.
	//This is a safe and good way to check if the server has the mod and if the client has the clientside.

	function GameConnection::onClientEnterGame(%client)
    {
		parent::onClientEnterGame(%client);
		%client.FBcheck = getRandom(0,999);
		commandtoclient(%client,'FB_ping',%client.FBcheck);
	}
	
	function servercmdFB_pong(%client,%x,%version)
	{
		if(%x == %client.FBcheck && !%client.FBfailed)
		{
			%client.hasFB = 1;
			if(%version$=$FB::Version)
				return;
			%a=strreplace(%version,"."," ");
			%b=strreplace($FB::Version,"."," ");
			if (getWord(%a,0) < getWord(%b,0) || (getWord(%a,0) == getWord(%b,0) && getWord(%a,1) < getWord(%b,1)) || (getWords(%a,0,1) == getWords(%b,0,1) && getWord(%a,2) < getWord(%b,2)))
				return messageClient(%client,'',"\c6Your Filmbots is outdated. Features may be unavailable.");
			if (getWord(%a,0) > getWord(%b,0) || (getWord(%a,0) == getWord(%b,0) && getWord(%a,1) > getWord(%b,1)) || (getWords(%a,0,1) == getWords(%b,0,1) && getWord(%a,2) > getWord(%b,2)))
				return messageClient(%client,'',"\c6Server Filmbots is outdated. Features may be unavailable.");
		
		}
		else
			%client.FBfailed=1;
	}
	
	function GameConnection::FBchecks(%client,%things,%arg0)
	{
		if(!%client.hasFB)
			return messageClient(%client,'',"\c6Must have FilmBots to use.");
		for(%i=0;%i<strlen(%things);%i++)
		{
			switch$(getsubstr(%things,%i,1))
			{
				case "1":
					if(!%client.highestfilm)
						return messageClient(%client,'',"\c6No films recorded. Use \c3/filmscene\c6 to begin filming.");
				case "2":
					if(%client.isFilming)
						return messageClient(%client,'',"\c6Filming in progress. Use \c3/endscene\c6 to finish filming.");
				case "3":
					if(%client.playback)
						return messageClient(%client,'',"\c6Playback in progress. Use \c3/endscene\c6 to end playback.");
				case "4":
					if(%arg0$="")
						return messageClient(%client,'',"\c6Specify a range such as \c31,3-6,8,12-\c6 or \c3all\c6. Use \c3/listscene\c6 to list scenes.");
			
			}
		}
		return true;
	}
	
	function servercmdfbf(%client)
	{
		servercmdfilmscene(%client);
	}
	
	function servercmdfilmscene(%client)
	{
		if(%client.fbchecks("2"))
		{
			for(%i=1;isObject(%client.filmscene[%i]);%i++) { }
			if(%i>%client.highestfilm)
				%client.highestfilm = %i;
			messageclient(%client,'',"\c2Filming Scene \c3"@%i@"\c2.");
			%client.isFilming=1;
			%client.lastFilm=%i;
			
			%client.filmscene[%i] = new scriptobject(filmscene)
			{
				name = %i;
				start = getsimtime();
				curraction = 0;
			};
			
			%client.filmscene = %client.filmscene[%i];
			%client.fakefilmbot[%client.filmscene.name] = new scriptobject(fakefilmbot)
			{
				datab = %client.player.getDatablock();
				place = %client.player.getTransform();
				accent = %client.accent;
				chest = %client.chest;
				hat = %client.hat;
				hip = %client.hip;
				lArm = %client.lArm;
				lHand = %client.lHand;
				lLeg = %client.lLeg;
				pack = %client.pack;
				rArm = %client.rArm;
				rHand = %client.rHand;
				rLeg = %client.rLeg;
				secondPack = %client.secondPack;
				accentColor = %client.accentColor;
				chestColor = %client.chestColor;
				hatColor = %client.hatColor;
				hipColor = %client.hipColor;
				lArmColor = %client.lArmColor;
				lHandColor = %client.lHandColor;
				lLegColor = %client.lLegColor;
				packColor = %client.packColor;
				rArmColor = %client.rArmColor;
				rHandColor = %client.rHandColor;
				rLegColor = %client.rLegColor;
				secondPackColor = %client.secondPackColor;
				decalName = %client.decalName;
				faceName = %client.faceName;
				headColor = %client.headColor;
				
				weapon = (%a=%client.player.currtool)==-1?-1:%client.player.tool[%a].image;
				look = %client.player.geteyevector();
				
			};
			
			commandToClient(%client,'FB_film', 1);
			%client.filmtimer(getSimTime());
		}
	}
	
	function servercmdfbw(%client,%scene)
	{
		servercmdfilmwithscene(%client,%scene);
	}
	
	function servercmdfilmwithscene(%client,%scene)
	{
		servercmdplayscene(%client,%scene);
		servercmdfilmscene(%client);
	}
	
	function gameConnection::filterscene(%client,%scene)
	{
		%h=%client.highestfilm;
		%scene = %scene$="all" ? "-"@%h : (%scene$="last" ?%client.lastfilm:strreplace(%scene,","," "));
		for(%i=0;%i<getWordCount(%scene);%i++)
		{
			%temp = strreplace(getWord(%scene,%i),"-"," ");
			if(getWordCount(%temp SPC "")>1)
			{
				if((%a=getWord(%temp,0))<1 || %a>%h)
					%a=1;
				if((%b=getWord(%temp,1))<%a || %a>%h)
					%b=%h;
			}
			else if(%temp)
				%a=%b=%temp;
			else
				continue;
					
			for(%a;%a<=%b;%a++)
			{
				if(!isObject(%client.filmscene[%a]))
					%missing=addItemToList(%missing,%a);
				else if(iseventpending((%client.filmscene[%a].sched)))
					%playing=addItemToList(%playing,%a);
				else{
					%scenelist=addItemToList(%scenelist,%a);}
			}
		}
		
		return %missing TAB %playing TAB %scenelist;
	}
	
	function servercmdfbp(%client,%scene)
	{
		servercmdplayscene(%client,%scene);
	}
	
	function servercmdplayscene(%client, %scene)
	{
		if(%client.FBchecks("14",%scene))
		{
			%a=%client.filterscene(%scene);
			if((%b=getField(%a,0))!$="")messageClient(%client,'',"\c0Scenes not found\c6: "@%b);
			if((%b=getField(%a,1))!$="")messageClient(%client,'',"\c3Scenes already playing\c6: "@%b);
			if((%b=getField(%a,2))!$="")messageclient(%client,'',"\c2Playing Scene"@ (getWordCount(%b)>1?"s":"") @"\c6: "@%b@"\c2");
			for(%i=0;%i<getWordCount(%b);%i++)
			{
				%scene=getWord(%b,%i);
			
				%client.playback++;
				if(!%client.isFilming)
					%client.filmtimer(getsimtime());
				
				%client.filmscene = %client.filmscene[%scene];
				%cl = %client.fakefilmbot[%client.filmscene.name];
				%filmbot = %client.filmbot[%client.filmscene.name] = new AIPlayer(filmbot)
				{
					datablock=%cl.datab;
					owner=%client;
					
					accent = %cl.accent;
					chest = %cl.chest;
					hat = %cl.hat;
					hip = %cl.hip;
					lArm = %cl.lArm;
					lHand = %cl.lHand;
					lLeg = %cl.lLeg;
					pack = %cl.pack;
					rArm = %cl.rArm;
					rHand = %cl.rHand;
					rLeg = %cl.rLeg;
					secondPack = %cl.secondPack;
					accentColor = %cl.accentColor;
					chestColor = %cl.chestColor;
					hatColor = %cl.hatColor;
					hipColor = %cl.hipColor;
					lArmColor = %cl.lArmColor;
					lHandColor = %cl.lHandColor;
					lLegColor = %cl.lLegColor;
					packColor = %cl.packColor;
					rArmColor = %cl.rArmColor;
					rHandColor = %cl.rHandColor;
					rLegColor = %cl.rLegColor;
					secondPackColor = %cl.secondPackColor;
					decalName = %cl.decalName;
					faceName = %cl.faceName;
					headColor = %cl.headColor;
		
				};
				%filmbot.player = %filmbot;
		
		
				GameConnection::ApplyBodyParts(%filmbot);
				GameConnection::ApplyBodyColors(%filmbot);
		
				%filmbot.setTransform(%cl.place);
				%filmbot.setAimVector(%cl.look);
				if(%cl.weapon!=-1)
				{
					%filmbot.updateArm(%cl.weapon);
					%filmbot.mountImage(%cl.weapon,0);
				}
		
				%client.filmscene.replaystart = getsimtime();
				%client.filmscene.currreplay = 0;
				filmscene_tick(%client, %scene);
			}
		}
	}
	
	function filmscene_tick(%client, %scene)
	{
		%currScene = %client.filmscene[%scene];
		if(iseventpending(%currScene.sched))
			cancel(%currScene.sched);
		
		%bot = %client.filmbot[%scene];
			
		%currScene.sched = schedule(1, 0, filmscene_tick, %client, %scene);
		%a = getsimtime() - %currScene.replaystart;
		while(%a >= %currScene.time[%currScene.currreplay])
		{
			if(isObject(%bot) && %currScene.time[%currScene.currreplay] !$= "")
			{
				%command = %currScene.action[%currScene.currreplay];
				%action = firstword(%command);
				%x = restwords(%command);
				switch(%action){
					case 1:
						if(%bot.headturn)
						{
							if(getfieldcount(%x)>1)
							{
								%bot.currheadangle+=getfield(%x,1);
								if(%bot.currheadangle>3.14159)
									%bot.currheadangle=3.14159;
								if(%bot.currheadangle<-3.14159)
									%bot.currheadangle=-3.14159;
								%bot.setheadangle(%bot.currheadangle);
							}
							else
							{
								%bot.setAimVector(getWords(%bot.getforwardvector(),0,1) SPC getWord(%x,2));
							}
						}
						else
							%bot.setAimVector(getField(%x,0));
					case 2:
						%bot.setmovey(%x*(%bot.walking?0.375:1));
					case 3:
						%bot.setmovey(-%x*(%bot.walking?0.45:1));
					case 4:
						if(%bot.ismounted())
							%bot.setmoveyaw(-%x);
						else
							%bot.setmovex(-%x*(%bot.walking?0.44:1));
					case 5:
						if(%bot.ismounted())
							%bot.setmoveyaw(-%x);
						else
							%bot.setmovex(%x*(%bot.walking?0.44:1));
					case 6:
						%bot.setJumping(%x);
					case 7:
						%bot.setCrouching(%x);
					case 8:
						%bot.setJetting(%x);
					case 9:
						if(%bot.getMountedImage(0) && !%bot.isdisabled())
							%bot.setImageTrigger(0,%x);
						else
							Armor::OnTrigger(%bot.getDatablock(),%bot,0,%x);
					case 10:
						%bot.kill();
					case 11:
						servercmdlight(%bot);
					case 12:
						servercmdsit(%bot);
					case 13:
						servercmdunusetool(%bot);
					case 14:
						%bot.updateArm(%x);%bot.mountImage(%x,0);
					case 15:
						servercmdusespraycan(%bot,%x);
					case 16:
						if(%x)%bot.emote("loveimage");
					case 17:
						if(%x)%bot.emote("hateimage");
					case 18:
						if(%x)%bot.emote("wtfimage");
					case 19:
						if(%x)%bot.emote("alarmprojectile");
					case 20:
						%bot.headturn=%x;
						%bot.currheadangle=0;
						%bot.setheadangle(0);
					case 21:
						%bot.walking=%x;
					case 22:
						%bot.playThread(0, (%x?"talk":"root"));
				}
				%currScene.currreplay++;
			}
			else
			{
				servercmdendscene(%client, %scene);
				return;
			}
		}
	}
	
	function gameConnection::filmtimer(%client,%start)
	{
		cancel(%client.timesched);
		
		%mili = getSimTime()-%start;
		%mili -= (%sec = mfloor(%mili / 1000))*1000;
		%sec -= (%min = mfloor(%sec / 60))*60;
		
		%client.bottomprint("\c4Scene Time\c6: "@ (%min?%min@" min ":"") @%sec@ " sec "@%mili@" ms",2);
			
		%client.timesched = %client.schedule(10,"filmtimer",%start);
		
	}
	
	function servercmdfbe(%client,%scene)
	{
		servercmdendscene(%client,%scene);
	}
	
	function servercmdendscene(%client, %scene)
	{
		if(%client.isFilming && !%scene)
		{
			%k=1;
			messageclient(%client,'',"FilmBot ended.");
			%client.isFilming=0;
			commandToClient(%client,'FB_film',0);
			%reltime = (%scene $= "dead" ? 6000 : 0) + getsimtime() - %client.filmscene.start;
			%client.filmscene.time[%client.filmscene.curraction] = %reltime;
			%client.filmscene.total = %reltime;
		}
		
		if(%client.playback)
		{
			%k=1;
			if(%scene)
				fb::endscene(%client,%scene);
			else
			{
				messageclient(%client,'',"Playback ended.");
				for(%i=1;%i<=%client.highestfilm;%i++)
					fb::endscene(%client,%i);
			}
		}
		if(!%client.playback && !%client.isFilming)
			cancel(%client.timesched);
		
		if(!%k)
			messageClient(%client,'',"\c6Nothing in progress. Use \c3/filmscene\c6, \c3/playscene\c6, or \c3/listscene\c6.");	
	}
	
	function FB::endscene(%c,%scene)
	{
		if(iseventpending(%a = %c.filmscene[%scene].sched))
		{
			%k=1;
			cancel(%a);
		}
		if(isObject(%a = %c.filmbot[%scene]))
		{
			%k=1;
			%a.delete();
		}
		if(%k)
			%c.playback--;
	}
	
	function servercmdfbl(%client)
	{
		servercmdlistscene(%client);
	}
	
	function servercmdlistscene(%client)
	{
		if(%client.FBchecks("12"))
		{
			for(%i=1;%i<=%client.highestfilm;%i++)
			{
				if(isObject(%client.filmscene[%i]))
				{
					%mili = %client.filmscene[%i].total;
					%sec = mfloor(%mili / 1000);
					%mili = %mili - (%sec * 1000);
					messageClient(%client,'',"\c4Scene " @%i@ "\c6: " @%sec@ " sec "@%mili@" ms");
				}
			}
		}
	}
	
	function servercmdfbd(%client,%scene)
	{
		servercmddeletescene(%client,%scene);
	}
	
	function servercmddeletescene(%client, %scene)
	{
		if(%client.FBchecks("1234",%scene))
		{
			if((%b=getField(%client.filterscene(%scene),2))$="")
				messageclient(%client,'',"\c6No scenes found. Use \c3/listscene\c6 to list scenes.");
			else
			{
				messageclient(%client,'',"\c0Deleting Scene"@ (getWordCount(%b)>1?"s":"") @"\c6: "@%b@"\c2");
				for(%i=0;%i<getWordCount(%b);%i++)
				{
					%scene=getWord(%b,%i);
				
					if(isObject(%a=%client.filmbot[%scene]))%a.delete();
					%client.fakefilmbot[%scene].delete();
					%client.filmscene[%scene].delete();
					if(%scene >= %client.highestfilm)
					{
						while(!isObject(%client.filmscene[%client.highestfilm]) && %client.highestfilm > 0)
							%client.highestfilm--;
					}
				}
			}
		}
	}
	
	function servercmdFB_film(%client, %command, %x)
	{
		if(!isobject(%client.filmscene))
			return;
		%client.filmscene.action[%client.filmscene.curraction] = %command SPC %x;
		%client.filmscene.time[%client.filmscene.curraction] = getsimtime() - %client.filmscene.start;
		%client.filmscene.curraction++;
	}
	
	function servercmdFB_eyes(%client,%x)
	{
		servercmdFB_film(%client, 1,%client.player.geteyevector() @ (%x$=""?"":"" TAB %x) );
	}
	
	function servercmdFB_tools(%client)
	{
		if(%client.player.currTool>=0)
			servercmdFB_film(%client, 14,%client.player.tool[%client.player.currTool].image);
		else if(%client.player.getMountedImage(0).item$="spraycan")
			servercmdFB_film(%client, 15,%client.currentcolor);
		else
			servercmdFB_film(%client, 13);
	}
	
	function servercmdfbds(%client)
	{
		servercmddamagescene (%client);
	}
	
	function servercmddamagescene(%client)
	{
		$FB::filmbotdamage=!$FB::filmbotdamage;
		messageclient(%client,'',"\c6Filmbot Damage is "@ ($FB::filmbotdamage ? "\c2ON" :"\c0OFF") @"\c6.");
	}
	
	function projectileData::onCollision( %this, %obj, %col, %normal, %speed )
	{
		if(%col.getname()$=filmbot)
		{
			if($FB::filmbotdamage)
				%col.damage(%obj, %normal, %this.directdamage, %this.directdamagetype);
		}
		else
			parent::onCollision( %this, %obj, %col, %normal, %speed );
	}
	
	function armor::onDisabled(%this,%obj,%a){
		parent::onDisabled(%this,%obj,%a);
		if(%obj.client.isFilming)
		{
			servercmdFB_film(%obj.client, 10);
			servercmdEndScene(%obj.client,"dead");
		}
	}
	
	function AIPlayer::validateavatarprefs(){
		return;
	}
	
	function servercmdfb_talk(%client,%x){
		servercmdFB_film(%client, 22, %x);
		%client.player.playThread(0, (%x?"talk":"root"));
	}
	
	function servercmdlove(%client){
		parent::servercmdlove(%client);
		servercmdFB_film(%client, 16, 1);
	}
	
	function servercmdhate(%client){
		parent::servercmdhate(%client);
		servercmdFB_film(%client, 17, 1);
	}
	
	function servercmdwtf(%client){
		parent::servercmdwtf(%client);
		servercmdFB_film(%client, 18, 1);
	}
	
	function servercmdconfusion(%client){
		parent::servercmdconfusion(%client);
		servercmdFB_film(%client, 18, 1);
	}
	
	function servercmdalarm(%client){
		parent::servercmdalarm(%client);
		servercmdFB_film(%client, 19, 1);
	}
	
	function servercmdsit(%client){
		parent::servercmdsit(%client);
		servercmdFB_film(%client, 12, 1);
	}
};

activatepackage(filmbots_server);


//-----
// Misc. & Support Functions
//-----
//addItemToList, hasItemOnList and removeItemFromList by Ephialtes
//Useful functions for manipulating space delimited lists
function addItemToList(%string,%item)
{
	if(hasItemOnList(%string,%item))
		return %string;

	if(%string $= "")
		return %item;
	else
		return %string SPC %item;
}
function hasItemOnList(%string,%item)
{
	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
			return 1;
	}
	return 0;
}
function removeItemFromList(%string,%item)
{
	if(!hasItemOnList(%string,%item))
		return %string;

	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
		{
			if(%i $= 0)
				return getWords(%string,1,getWordCount(%string));
			else if(%i $= getWordCount(%string)-1)
				return getWords(%string,0,%i-1);
			else
				return getWords(%string,0,%i-1) SPC getWords(%string,%i+1,getWordCount(%string));
		}
	}
}

function isInteger(%string)
{
    %search = "- 0 1 2 3 4 5 6 7 8 9";
    for(%i=0;%i<getWordCount(%search);%i++)
    {
        %string = strReplace(%string,getWord(%search,%i),"");
    }
    if(%string $= "")
        return true;
    return false;
}