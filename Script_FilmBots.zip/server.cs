//Ping-Pong is from the compass mod. All credits go to the original creator for this.
//This is a safe and good way to check if the server has the mod and if the client has the clientside.
package filmBots_server

{
	function GameConnection::onClientEnterGame(%client)
    {
		parent::onClientEnterGame(%client);
		%client.FBcheck = getRandom(0,99);
		commandtoclient(%client,'FB_ping',%client.FBcheck);
	}
	
	function servercmdFB_pong(%client,%x)
	{
		if(%x == %client.FBcheck)
			%client.hasFB = 1;
	}

	
	function FB::checkstuff(%client)
	{
		if(%client.isFilming)
			return messageClient(%client,'',"\c6Filming in progress. Use \c3/endscene\c6 to finish filming.");
		else if(!%client.hasFB)
			return messageClient(%client,'',"\c6Must have FilmBots to use.");	
		else
			return true;
	}
	
	function servercmdfilmscene(%client)
	{
		if(FB::checkstuff(%client))
		{
			for(%i=1;isObject(%client.filmscene[%i]);%i++) { }
			if(%i>%client.highestfilm)
				%client.highestfilm = %i;
			messageclient(%client,'',"\c2Filming Scene \c3"@%i@"\c2.");
			%client.isFilming=1;
			
			%client.filmscene[%i] = new scriptobject(filmscene)
			{
				name = %i;
				start = getsimtime();
				curraction = 0;
			};
			
			%client.filmscene = %client.filmscene[%i];
			%client.fakefilmbot[%client.filmscene.name] = new scriptobject(fakefilmbot)
			{
				datab = %client.player.getDatablock();
				place = %client.player.getTransform();
				accent = %client.accent;
				chest = %client.chest;
				hat = %client.hat;
				hip = %client.hip;
				lArm = %client.lArm;
				lHand = %client.lHand;
				lLeg = %client.lLeg;
				pack = %client.pack;
				rArm = %client.rArm;
				rHand = %client.rHand;
				rLeg = %client.rLeg;
				secondPack = %client.secondPack;
				accentColor = %client.accentColor;
				chestColor = %client.chestColor;
				hatColor = %client.hatColor;
				hipColor = %client.hipColor;
				lArmColor = %client.lArmColor;
				lHandColor = %client.lHandColor;
				lLegColor = %client.lLegColor;
				packColor = %client.packColor;
				rArmColor = %client.rArmColor;
				rHandColor = %client.rHandColor;
				rLegColor = %client.rLegColor;
				secondPackColor = %client.secondPackColor;
				decalName = %client.decalName;
				faceName = %client.faceName;
				headColor = %client.headColor;
			};
			
			commandToClient(%client,'FB_film', 1);
			%client.filmtimer(0);
		}
	}
	
	function servercmdfilmwithscene(%client,%scene)
	{
		servercmdplayscene(%client,%scene);
		servercmdfilmscene(%client);
		
	}
	
	function servercmdplayscene(%client, %scene)
	{
		if(!%client.hasFB)
			return messageClient(%client,'',"\c6Must have FilmBots to use.");
		else if(!%client.highestfilm)
			return messageClient(%client,'',"\c6No films recorded. Use \c3/filmscene\c6 to begin filming.");
		else if(%scene$="")
			return messageClient(%client,'',"\c6Please specify a scene number. Use \c3/listscene\c6 or \c3/playscene all\c6.");
		else if(%scene$="all")
		{
			for(%i=1;%i<=%client.highestfilm;%i++)
			{
				if(isObject(%client.filmscene[%i]))
					servercmdplayscene(%client, %i);
			}
		}
		else if(!isObject(%client.filmscene[%scene]))
			return messageClient(%client,'',"\c6Scene \c3"@%scene@"\c6 not found.");
		else if(iseventpending((%client.filmscene[%scene].sched)))
			return messageClient(%client,'',"\c6Scene \c3"@%scene@"\c6 already playing. Use \c3/endscene\c6 to cancel playback.");
		else
		{
			%client.playback++;
			%client.filmtimer(0);
			messageclient(%client,'',"\c2Playing Scene \c3"@%client.filmscene[%scene].name@"\c2.");
			
			%client.filmscene = %client.filmscene[%scene];
			%cl = %client.fakefilmbot[%client.filmscene.name];
			%client.filmbot[%client.filmscene.name] = new AIPlayer(filmbot)
			{
				datablock=%cl.datab;
				
				accent = %cl.accent;
				chest = %cl.chest;
				hat = %cl.hat;
				hip = %cl.hip;
				lArm = %cl.lArm;
				lHand = %cl.lHand;
				lLeg = %cl.lLeg;
				pack = %cl.pack;
				rArm = %cl.rArm;
				rHand = %cl.rHand;
				rLeg = %cl.rLeg;
				secondPack = %cl.secondPack;
				accentColor = %cl.accentColor;
				chestColor = %cl.chestColor;
				hatColor = %cl.hatColor;
				hipColor = %cl.hipColor;
				lArmColor = %cl.lArmColor;
				lHandColor = %cl.lHandColor;
				lLegColor = %cl.lLegColor;
				packColor = %cl.packColor;
				rArmColor = %cl.rArmColor;
				rHandColor = %cl.rHandColor;
				rLegColor = %cl.rLegColor;
				secondPackColor = %cl.secondPackColor;
				decalName = %cl.decalName;
				faceName = %cl.faceName;
				headColor = %cl.headColor;
			
			};
			%filmbot = %client.filmbot[%client.filmscene.name];
			%filmbot.player = %filmbot;
			
			
			GameConnection::ApplyBodyParts(%filmbot);
			GameConnection::ApplyBodyColors(%filmbot);
			
			%filmbot.setTransform(%cl.place);
			
			%client.filmscene.replaystart = getsimtime();
			%client.filmscene.currreplay = 0;
			filmscene_tick(%client, %scene);
		}
	}
	
	function filmscene_tick(%client, %scene)
	{
		%currScene = %client.filmscene[%scene];
		
		if(iseventpending(%currScene.sched))
			cancel(%currScene.sched);
			
		%currScene.sched = schedule(1, 0, filmscene_tick, %client, %scene);
		%a = getsimtime() - %currScene.replaystart;
		%client.filmtimer(%a);
		while(%a >= %currScene.time[%currScene.currreplay])
		{
			if(isObject(%client.filmbot[%scene]) && %currScene.time[%currScene.currreplay] !$= "")
			{
				eval(%currScene.action[%currScene.currreplay]);
				%currScene.currreplay++;
			}
			else
			{
				servercmdendscene(%client, %scene);
				return;
			}
		}
	}
	
	function gameConnection::filmtimer(%client,%sync)
	{
		cancel(%client.timesched);
		if(%sync)
			%client.timer=%sync;
		else
			%client.timer+=10;
		%mili = %client.timer;
		%mili -= (%sec = mfloor(%mili / 1000))*1000;
		%sec -= (%min = mfloor(%sec / 60))*60;
		
		%client.bottomprint("\c4Scene Time\c6: "@ (%min?%min@" min ":"") @%sec@ " sec "@%mili@" ms",2);
			
		%client.timesched = %client.schedule(10,"filmtimer");
		
	}
	function servercmdendscene(%client, %scene)
	{
		if(%client.isFilming && !%scene)
		{
			%k=1;
			messageclient(%client,'',"FilmBot ended.");
			%client.isFilming=0;
			commandToClient(%client,'FB_film',0);
			%reltime = (%scene $= "suicide" ? 6000 : 0) + getsimtime() - %client.filmscene.start;
			%client.filmscene.time[%client.filmscene.curraction] = %reltime;
			%client.filmscene.total = %reltime;
		}
		
		if(%client.playback)
		{
			%k=1;
			if(%scene)
				fb::endscene(%client,%scene);
			else
			{
				messageclient(%client,'',"Playback ended.");
				for(%i=1;%i<=%client.highestfilm;%i++)
					fb::endscene(%client,%i);
			}
		}
		if(!%client.playback && !%client.isFilming)
			cancel(%client.timesched);
		
		if(!%k)
			messageClient(%client,'',"\c6Nothing in progress. Use \c3/filmscene\c6, \c3/playscene\c6, or \c3/listscene\c6.");	
	}
	
	function FB::endscene(%c,%scene)
	{
		if(iseventpending(%a = %c.filmscene[%scene].sched))
		{
			%k=1;
			cancel(%a);
		}
		if(isObject(%a = %c.filmbot[%scene]))
		{
			%k=1;
			%a.delete();
		}
		if(%k)
			%c.playback--;
	}
	
	function servercmdlistscene(%client)
	{
		if(!%client.hasFB)
			return messageClient(%client,'',"\c6Must have FilmBots to use.");
		else
		{
			if(%client.highestfilm)
			{
				for(%i=1;%i<=%client.highestfilm;%i++)
				{
					if(isObject(%client.filmscene[%i]))
					{
						%mili = %client.filmscene[%i].total;
						%sec = mfloor(%mili / 1000);
						%mili = %mili - (%sec * 1000);
						messageClient(%client,'',"\c4Scene " @%i@ "\c6: " @%sec@ " sec "@%mili@" ms");
					}
				}
			}
			else
				messageClient(%client,'',"\c6No films recorded. Use \c3/filmscene\c6 to begin filming.");
		}
	}
	
	function servercmddeletescene(%client, %scene)
	{
		if(FB::checkstuff(%client))
		{
			if(%client.playback)
				return messageClient(%client,'',"\c6Playback in progress. Use \c3/endscene\c6 to end playback.");
			if(%scene$="")
				return messageClient(%client,'',"\c6Please specify a scene number. Use \c3/listscene\c6 or \c3/deletescene all\c6.");
			if(isObject(%client.filmscene[%scene]))
			{
				messageClient(%client,'',"\c6Scene \c3"@%scene@"\c6 deleted.");
				%client.filmscene[%scene].delete();
				if(%scene >= %client.highestfilm)
				{
					while(!isObject(%client.filmscene[%client.highestfilm]) && %client.highestfilm > 0)
						%client.highestfilm--;
				}
			}
			else if(%scene$="all")
			{
				while(isObject(filmscene))
					filmscene.delete();
				while(isObject(filmbot))
					filmbot.delete();
				%client.highestfilm="0";
				messageClient(%client,'',"\c6All scenes deleted.");
			}
			else
				messageClient(%client,'',"\c6Scene \c3"@%scene@"\c6 not found.");
		}
	}
	
	function servercmdFB_film(%client, %command, %x)
	{
		if(!isobject(%client.filmscene))
			return;
		%client.filmscene.action[%client.filmscene.curraction] = strreplace($FB::command[%command],"%x",%x);
		%client.filmtimer(%client.filmscene.time[%client.filmscene.curraction] = getsimtime() - %client.filmscene.start);
		%client.filmscene.curraction++;
	}
	
	function servercmdFB_eyes(%client)
	{
		servercmdFB_film(%client, 1,%client.player.geteyevector());
	}
};

activatepackage(filmbots_server);

$FB::command1 = "%client.filmbot[%scene].setAimVector(\"%x\");";
$FB::command2 = "%client.filmbot[%scene].setmovey(%x);";
$FB::command3 = "%client.filmbot[%scene].setmovey(-%x);";
$FB::command4 = "%client.filmbot[%scene].setmovex(-%x);";
$FB::command5 = "%client.filmbot[%scene].setmovex(%x);";
$FB::command6 = "%client.filmbot[%scene].setJumping(%x);";
$FB::command7 = "%client.filmbot[%scene].setCrouching(%x);";
$FB::command8 = "%client.filmbot[%scene].setJetting(%x);";
$FB::command9 = "%client.filmbot[%scene].activatestuff(%x);";
$FB::command10 = "%client.filmbot[%scene].kill();";
$FB::command11= "servercmdlight(%client.filmbot[%scene]);";
$FB::command12 = "servercmdsit(%client.filmbot[%scene]);";

