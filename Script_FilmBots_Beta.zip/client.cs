//Ping-Pong is from the compass mod. All credits go to the original creator for this.
//This is a safe and good way to check if the server has the mod and if the client has the clientside.
$FB::Version=1;
function clientcmdFB_ping(%x)
{
	commandtoserver('FB_pong',%x,$FB::Version);
	$FBServer = 1;
	activatepackage(filmbots_client);
}

function clientcmdFB_Film(%toggle)
{
	if(%toggle)
	{
		$FB::Filming=1;
	}
	else
	{
		$FB::Filming=0;
	}
}

package filmbots_client
{
	function disconnect(%a)
	{
		if($FBServer)
		{
			commandtoserver('endscene');
			$FBServer = 0;
			deactivatepackage(filmbots_client);
		}
		Parent::disconnect(%a);
	}

	function yaw(%x)
	{
		
		parent::yaw(%x);
		if($FB::Filming)
			commandtoserver('FB_eyes');
	}
	function pitch(%x)
	{
		
		parent::pitch(%x);
		if($FB::Filming)
			commandtoserver('FB_eyes');
	}

	function moveforward(%x)
	{
		
		parent::moveforward(%x);
		if($FB::Filming)
			commandtoserver('FB_film',2,%x);
	}

	function movebackward(%x)
	{
		
		parent::movebackward(%x);
		if($FB::Filming)
			commandtoserver('FB_film',3,%x);
	}

	function moveleft(%x)
	{
		
		parent::moveleft(%x);
		if($FB::Filming)
			commandtoserver('FB_film',4,%x);
	}

	function moveright(%x)
	{
		
		parent::moveright(%x);
		if($FB::Filming)
			commandtoserver('FB_film',5,%x);
	}

	function jump(%x)
	{
		
		parent::jump(%x);
		if($FB::Filming)
			commandtoserver('FB_film',6,%x);
	}

	function crouch(%x)
	{
		
		parent::crouch(%x);
		if($FB::Filming)
			commandtoserver('FB_film',7,%x);
	}

	function jet(%x)
	{
		
		parent::jet(%x);
		if($FB::Filming)
			commandtoserver('FB_film',8,%x);
	}

	function mouseFire(%x)
	{
		
		parent::mouseFire(%x);
		if($FB::Filming)
			commandtoserver('FB_film',9,%x);
	}

	function Suicide(%x)
	{
		
		parent::Suicide(%x);
		if($FB::Filming)
		{
			commandtoserver('FB_film',10,%x);
			commandtoserver('endscene',"suicide");
		}
	}

	function useLight(%x)
	{
		
		parent::useLight(%x);
		if($FB::Filming)
			commandtoserver('FB_film',11,%x);
	}

	function emoteSit(%x)
	{
		
		parent::emoteSit(%x);
		if($FB::Filming)
			commandtoserver('FB_film',12,%x);
	}
	
};
